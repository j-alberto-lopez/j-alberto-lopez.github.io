package com.ipartek.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ipartek.modelo.Dificultad;
import com.ipartek.repositorio.DificultadRepositorio;

@Service
public class DificultadServicioImp implements DificultadServicio {

	@Autowired
	DificultadRepositorio repo;

	@Override
	public List<Dificultad> obtenerTodas() {

		return repo.findAll();
	}

	@Override
	public Dificultad obtenerPorId(int id) {

		return repo.findById(id).orElse(null);
	}

	@Override
	public Dificultad guardar(Dificultad dificultad) {

		return repo.save(dificultad);
	}

	@Override
	public void borrar(int id) {

		repo.deleteById(id);

	}
	
	
}
