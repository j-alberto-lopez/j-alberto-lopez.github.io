package com.ipartek.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ipartek.modelo.Rol;
import com.ipartek.repositorio.RolRepositorio;

@Service
public class RolServicioImp implements RolServicio {

	@Autowired
	private RolRepositorio repo;

	@Override
	public List<Rol> obtenerTodos() {
		return repo.findAll();
	}

	@Override
	public Rol obtenerPorId(int id) {
		return repo.findById(id).orElse(null);
	}

	@Override
	public Rol guardar(Rol rol) {
		return repo.save(rol);
	}

	@Override
	public void borrar(int id) {
		repo.deleteById(id);
	}
}