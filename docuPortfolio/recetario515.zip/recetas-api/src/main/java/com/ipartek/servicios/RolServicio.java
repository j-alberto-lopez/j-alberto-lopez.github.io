package com.ipartek.servicios;

import java.util.List;
import com.ipartek.modelo.Rol;

public interface RolServicio {

    List<Rol> obtenerTodos();

    Rol obtenerPorId(int id);

    Rol guardar(Rol rol);

    void borrar(int id);
}