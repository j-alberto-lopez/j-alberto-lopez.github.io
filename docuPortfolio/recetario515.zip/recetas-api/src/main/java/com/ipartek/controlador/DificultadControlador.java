package com.ipartek.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ipartek.modelo.Dificultad;
import com.ipartek.servicios.DificultadServicio;

@RestController
@RequestMapping("/api/v1/dificultades")
public class DificultadControlador {

    @Autowired
    private DificultadServicio servicio;

    
    @GetMapping
    public ResponseEntity<List<Dificultad>> obtenerTodas() {
        return ResponseEntity.ok(servicio.obtenerTodas());
    }

    
    @GetMapping("/{id}")
    public ResponseEntity<Dificultad> obtenerPorId(@PathVariable int id) {

        Dificultad dificultad = servicio.obtenerPorId(id);

        if (dificultad == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(dificultad);
    }

    
    @PostMapping
    public ResponseEntity<Dificultad> guardar(@RequestBody Dificultad dificultad) {
        return ResponseEntity.ok(servicio.guardar(dificultad));
    }

   
    @PutMapping("/{id}")
    public ResponseEntity<Dificultad> modificar(@PathVariable int id, @RequestBody Dificultad dificultad) {
        dificultad.setId(id);
        return ResponseEntity.ok(servicio.guardar(dificultad));
    }

    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrar(@PathVariable int id) {
        servicio.borrar(id);
        return ResponseEntity.noContent().build();
    }
}