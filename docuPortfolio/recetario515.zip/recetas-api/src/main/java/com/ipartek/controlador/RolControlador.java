package com.ipartek.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ipartek.modelo.Rol;
import com.ipartek.servicios.RolServicio;

@RestController
@RequestMapping("/api/v1/roles/")
public class RolControlador {

    @Autowired
    private RolServicio servicio;

    
    @GetMapping
    public ResponseEntity<List<Rol>> obtenerTodos() {
        return ResponseEntity.ok(servicio.obtenerTodos());
    }

    
    @GetMapping("/{id}")
    public ResponseEntity<Rol> obtenerPorId(@PathVariable int id) {

        Rol rol = servicio.obtenerPorId(id);

        if (rol == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(rol);
    }

    
    @PostMapping
    public ResponseEntity<Rol> guardar(@RequestBody Rol rol) {
        return ResponseEntity.ok(servicio.guardar(rol));
    }

   
    @PutMapping("/{id}")
    public ResponseEntity<Rol> modificar(@PathVariable int id, @RequestBody Rol rol) {
        rol.setId(id);
        return ResponseEntity.ok(servicio.guardar(rol));
    }

   
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrar(@PathVariable int id) {
        servicio.borrar(id);
        return ResponseEntity.noContent().build();
    }
}