package com.ipartek.servicios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.ipartek.auxiliar.Auxiliar;
import com.ipartek.componentes.JwtUtil;
import com.ipartek.modelo.Usuario;
import com.ipartek.pojos.MsgError;
import com.ipartek.repositorio.UsuarioRepositorio;

@Service
public class UsuarioServicioImp implements UsuarioServicio {

	@Autowired
	private UsuarioRepositorio usuarioRepo;
	
	@Autowired
	private JwtUtil jwtUtil;

	@Override
	public ResponseEntity<?> obtenerTodosUsuarios() {
		try {
			return ResponseEntity.status(200).body(usuarioRepo.findAll());
		} catch (Exception e) {
			return ResponseEntity.status(500).body(new MsgError(500, "Error al obtener todos losUsuarios"));
		}
	}

	@Override
	public ResponseEntity<?> obtenerUsuarioPorId(String id) {
		try {
			int idReal = Integer.parseInt(id);

			Usuario usuTemp = usuarioRepo.findById(idReal).orElse(new Usuario());
			return ResponseEntity.status(200).body(usuTemp);
		} catch (NumberFormatException e) {
			return ResponseEntity.status(400).body(new MsgError(400, "Error, el id no es numerico"));
		} catch (Exception e) {
			return ResponseEntity.status(500).body(new MsgError(500, "Error al obtener El usuario por id"));
		}
	}

	@Override
	public ResponseEntity<?> obtenerUsuarioPorNombre(String nombre) {	
		try {
			return ResponseEntity.status(200).body(usuarioRepo.findByUser(nombre));
		} catch (NumberFormatException e) {
			return ResponseEntity.status(400).body(new MsgError(400, "Error, el id no es numerico"));
		} catch (Exception e) {
			return ResponseEntity.status(500).body(new MsgError(500, "Error al obtener El usuario por id"));
		}
	}

	@Override
	public ResponseEntity<?> guardarUsuario(String usu) {
		try {
			Gson gs=new Gson();
			Usuario usuarioTemp= gs.fromJson(usu, Usuario.class);
			
			
			//
			// GEnerar el usuario con la sal y todo
			// aqui deberia llegar un usuario con SHA(1234+Kolitza) 
			//
			
			if (usuarioTemp instanceof Usuario) {
				return ResponseEntity.status(200).body(usuarioRepo.save(usuarioTemp)) ;
			}
			return ResponseEntity.status(500).body(new MsgError(500, "Error")) ;
		} catch (JsonSyntaxException e) {
			return ResponseEntity.status(400).body(new MsgError(400, "Error 400 al insertar usuario")) ;
			
		} catch (Exception e) {
			return ResponseEntity.status(500).body(new MsgError(500, "Error generico al insertar usuario")) ;
		}
		
	}

	@Override
	public ResponseEntity<?> modificarUsuario(String usu) {

		try {
			Gson gs=new Gson();
			Usuario usuarioTemp= gs.fromJson(usu, Usuario.class);
			
			if (usuarioTemp instanceof Usuario) {
				return ResponseEntity.status(200).body(usuarioRepo.save(usuarioTemp)) ;
			}
			return ResponseEntity.status(500).body(new MsgError(500, "Error")) ;
		} catch (JsonSyntaxException e) {
			return ResponseEntity.status(400).body(new MsgError(400, "Error 400 al insertar usuario")) ;
			
		} catch (Exception e) {
			return ResponseEntity.status(500).body(new MsgError(500, "Error generico al insertar usuario")) ;
		}
	}

	@Override
	public ResponseEntity<?> borrarUsuario(String id) {
		try {
			int idReal = Integer.parseInt(id);
			usuarioRepo.deleteById(idReal);
			
			ResponseEntity<?> usuario=obtenerUsuarioPorId(String.valueOf(idReal));
			
			Usuario usuarioTemp = (Usuario)usuario.getBody();
			if (   usuarioTemp.getId() == 0  ) {
				return ResponseEntity.status(200).body(true) ;		
			}else {
				return ResponseEntity.status(500).body(new MsgError(500, "NO SE BORRO POR QU NO ESTABA")) ;
			}	
		} catch (NumberFormatException e) {
			return ResponseEntity.status(400).body(new MsgError(400, "Error, el id no es numerico")) ;
		} catch (Exception e) {
			return ResponseEntity.status(500).body(new MsgError(500, "Error general al borrar usuario")) ;
		}
	}

	@Override
	public ResponseEntity<?> obtenerTodosUsuariosSaneados() {
		try {
			return ResponseEntity.status(200).body(usuarioRepo.findAllSaniticed());
		} catch (Exception e) {
			return ResponseEntity.status(500).body(new MsgError(500, "Error al obtener todos losUsuarios"));
		}
		
		
		
	}

	@Override
	public ResponseEntity<?> validarUsuario(String usu) {
		try {
			Gson gs = new Gson();
			Usuario usuario=gs.fromJson(usu, Usuario.class);
			
			Usuario usuTemp=usuarioRepo.findByUser(usuario.getUser());
			
			if (usuTemp!=null ) {
				
				String passTemp=usuario.getPass()+usuTemp.getSalt();
				
				String passTempHasheado=Auxiliar.hashear(passTemp);
				
				if (passTempHasheado.equalsIgnoreCase(usuTemp.getPass())  
						&& (usuTemp.getRol().getId()==1 || usuTemp.getRol().getId()==2) ) {
		
					String token=jwtUtil.generateToken(usuTemp.getUser(), usuTemp.getRol().getNombre());

					return ResponseEntity.status(200).body(token);
				}

				return ResponseEntity.status(500).body(new MsgError(500,"Pass mal metida"));
			}else {
				return ResponseEntity.status(500).body(new MsgError(500,"Usuario inexistente"));
			}			
		} catch (NumberFormatException e) {
			return ResponseEntity.status(400).body(new MsgError(400, "Error, mal formateado"));
		} catch (Exception e) {
			return ResponseEntity.status(500).body(new MsgError(500, "Error al obtener El usuario"));
		}
	}

}