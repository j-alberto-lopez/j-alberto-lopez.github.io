package com.ipartek.servicios;

import org.springframework.http.ResponseEntity;

public interface UsuarioServicio {
	ResponseEntity<?> obtenerTodosUsuarios();
	ResponseEntity<?> obtenerUsuarioPorId(String id);
	ResponseEntity<?> obtenerUsuarioPorNombre(String nombre);
	ResponseEntity<?> guardarUsuario(String usu);
	ResponseEntity<?> modificarUsuario(String usu);
	ResponseEntity<?> borrarUsuario(String id);
	ResponseEntity<?> obtenerTodosUsuariosSaneados();
	
	ResponseEntity<?> validarUsuario(String usu);
	
}