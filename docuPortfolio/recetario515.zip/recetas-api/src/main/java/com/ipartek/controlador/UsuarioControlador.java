package com.ipartek.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipartek.servicios.UsuarioServicio;

@RestController
@RequestMapping("/api/v1/usuarios/")
public class UsuarioControlador {
	
	@Autowired
	private UsuarioServicio usuarioServ;
	

	
	@PostMapping("/ValidarUsuario")
	public ResponseEntity<?> validarUsuarioREST( @RequestBody String usu) {
		return usuarioServ.validarUsuario(usu);
	}
	
	@GetMapping("")
	public ResponseEntity<?> obtenerTodosUsuariosREST(){
		return usuarioServ.obtenerTodosUsuarios();
	}
	
	@GetMapping("{id}")
	public ResponseEntity<?> obtenerUsuarioPorIdREST(@PathVariable String id){
		return usuarioServ.obtenerUsuarioPorId(id);
	}
	
	@PostMapping("")
	public ResponseEntity<?> insertarUsuarioREST(@RequestBody String usu){
		return usuarioServ.guardarUsuario(usu);
	}
	
	@PutMapping("")
	public ResponseEntity<?> modificarTipoREST(@RequestBody String usu){
		return usuarioServ.modificarUsuario(usu);
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<?> borrarUsuarioREST(@PathVariable String id){
		return usuarioServ.borrarUsuario(id);
	}
	
	
}