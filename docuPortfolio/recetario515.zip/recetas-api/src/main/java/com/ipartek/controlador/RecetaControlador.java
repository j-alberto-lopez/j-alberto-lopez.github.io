package com.ipartek.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ipartek.modelo.Receta;
import com.ipartek.servicios.RecetaServicio;

@RestController
@RequestMapping("/api/v1/recetas")
public class RecetaControlador {

	@Autowired
	private RecetaServicio servicio;

	@GetMapping
	public ResponseEntity<List<Receta>> obtenerTodas() {
		return ResponseEntity.ok(servicio.obtenerTodas());
	}

	@GetMapping("/{id}")
	public ResponseEntity<Receta> obtenerPorId(@PathVariable int id) {

		Receta receta = servicio.obtenerPorId(id);

		if (receta == null) {
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(receta);
	}

	@PostMapping
	public ResponseEntity<Receta> guardar(@RequestBody Receta receta) {
		return ResponseEntity.ok(servicio.guardar(receta));
	}

	@PutMapping("/{id}")
	public ResponseEntity<?> editar(@PathVariable int id, @RequestBody Receta receta) {

		Receta existente = servicio.obtenerPorId(id);

		if (existente == null) {
			return ResponseEntity.notFound().build();
		}

		receta.setId(id);

		Receta actualizada = servicio.guardar(receta);

		return ResponseEntity.ok(actualizada);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> borrar(@PathVariable int id) {
		servicio.borrar(id);
		return ResponseEntity.noContent().build();
	}
}
