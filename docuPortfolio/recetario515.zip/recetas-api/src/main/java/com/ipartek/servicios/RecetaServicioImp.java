package com.ipartek.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ipartek.modelo.Receta;
import com.ipartek.repositorio.RecetaRepositorio;

@Service
public class RecetaServicioImp implements RecetaServicio {

	@Autowired
	private RecetaRepositorio repo;

	@Override
	public List<Receta> obtenerTodas() {
		return repo.findAll();
	}

	@Override
	public Receta obtenerPorId(int id) {
		return repo.findById(id).orElse(null);
	}

	@Override
	public Receta guardar(Receta receta) {
		return repo.save(receta);
	}

	@Override
	public void borrar(int id) {
		repo.deleteById(id);
	}
	
	@Override
	public Receta modificar(Receta receta) {
		 return repo.save(receta);
	}
}