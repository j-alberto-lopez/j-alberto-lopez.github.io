package com.servetracker.servicio;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import com.servetracker.dtos.ElementoListadoProductoRespuesta;
import com.servetracker.excepciones.NoEncontradoException;
import com.servetracker.modelo.LineaPedido;
import com.servetracker.modelo.Pedido;
import com.servetracker.modelo.Producto;
import com.servetracker.modelo.TipoProducto;
import com.servetracker.repositorio.LineaPedidoRepositorio;
import com.servetracker.repositorio.LineaTicketRepositorio;
import com.servetracker.repositorio.ProductoRepositorio;

@ExtendWith(MockitoExtension.class)
public class ProductoServicioImplTest {

	@Mock
	private ProductoRepositorio pr;
	
	@Mock
	private LineaPedidoRepositorio lpr;

    @Mock
    private LineaTicketRepositorio lineaTicketRepositorio;
	
	@InjectMocks
	private ProductoServicioImpl ps;


	@Test
	public void testObtenerProductoPorIdConIdValido() throws NoEncontradoException {
		
		Producto p = new Producto(1, "prueba", TipoProducto.BEBIDA, 1, 1, 1, null, null);
		
		when(pr.findById(1)).thenReturn(Optional.of(p));
		
		Producto result = ps.obtenerPorId(1);
				
		assertNotNull(result);
		assertEquals("prueba", result.getNombre());		
	}
	
	@Test
	public void testObtenerProductoPoIdConIdNoExistente() {
		when(pr.findById(1)).thenReturn(Optional.empty());
		
		assertThrows(NoEncontradoException.class, () -> {
			ps.obtenerPorId(1);
		});
		
	}
	
	// Probar insertar producto con nombre a null o vacio
	@Test
	public void testInsertarProductoConNombreVacio() throws IllegalArgumentException {
		
		Producto p = new Producto(1, "", TipoProducto.BEBIDA, 1,1, null, null);
		
		assertThrows(IllegalArgumentException.class, ()->{
		ps.guardar(p);
		});
	}
	@Test
	public void testInsertarProductoConNombreNull() throws IllegalArgumentException {
		
		Producto p = new Producto(1, null, TipoProducto.BEBIDA, 1,1, null, null);
		
		assertThrows(IllegalArgumentException.class, ()->{
		ps.guardar(p);
		});
	}
	// Probar insertar poducto con precio venta 0 o negativo
	@Test
	public void testInsertarProductoConPrecioVenta0() throws IllegalArgumentException {
		
		Producto p = new Producto(1, "prueba", TipoProducto.BEBIDA, 0,1, null, null);
		
		assertThrows(IllegalArgumentException.class, ()->{
		ps.guardar(p);
		});
	}
	
	@Test
	public void testInsertarProductoConPrecioVentaNegativo() throws IllegalArgumentException {
		
		Producto p = new Producto(1, "prueba", TipoProducto.BEBIDA, -5, 1, null, null);
		
		assertThrows(IllegalArgumentException.class, ()->{
		ps.guardar(p);
		});
	}
	
	// Probar insertar producto correcto
	
	@Test
	public void testInsertarProductoCorrecto() {

	    Producto p = new Producto(1, "prueba", TipoProducto.BEBIDA, 1, 1, null, null);

	    //swhen(pr.save(p)).thenReturn(p);

	    Producto result = ps.guardar(p);
	    
	    verify(pr, times(1)).save(any());
	    
	    //assertNotNull(result);
	    //assertEquals("prueba", result.getNombre());
	}
	
	@Test
	public void testObtenerListadoVacio() {
		when(pr.findAll()).thenReturn(new ArrayList<>());
		List<ElementoListadoProductoRespuesta> r = ps.obtenerListado();
		assertEquals(0, r.size());
	}
	

	@Test
	public void testObtenerListadoCompleto() {
		Producto p = new Producto(1, "Producto sin pedidos", TipoProducto.BEBIDA, -5, 1, null, null);
		Producto p1 = new Producto(1, "pedido sin stock", TipoProducto.BEBIDA, -5, 1, null, null);
		
		LineaPedido lp = new LineaPedido(100, new BigDecimal(150), new BigDecimal(1.5), 0, p1);
		
		when(pr.findAll()).thenReturn(List.of(p));
		
		when(lpr.findByProductoAndCantidadDisponibleGreaterThanOrderByPedidoFechaAsc(p, 0)).thenReturn(new ArrayList<>());
		when(lpr.findTopByProductoOrderByPedido_FechaDesc(p)).thenReturn(Optional.empty());

		when(lpr.findByProductoAndCantidadDisponibleGreaterThanOrderByPedidoFechaAsc(p1, 0)).thenReturn(new ArrayList<>());
		when(lpr.findTopByProductoOrderByPedido_FechaDesc(p1)).thenReturn(Optional.of(lp));
		
		List<ElementoListadoProductoRespuesta> r = ps.obtenerListado();
		
		assertEquals(1, r.size());
		
		// 2.1.1 Calcular precio de compra cuando no hay pedidos
		assertEquals(0.0, r.get(0).getPrecioCompra());
		//2.1.2 Calcular precio de compra cuando hay pedidos pero no hay stock
		assertEquals(1.5, r.get(1).getPrecioCompra());
		
	}
	
	
	
	
	
	
	
}

/*
1 No hay productos
2 Hay productos
2,1 Precio de compra
2.1.1 Calcular precio de compra cuando no hay pedidos
		- Un producto sin pedidos tiene precio de compra 0
2.1.2 Calcular precio de compra cuando hay pedidos pero no hay stock
2.1.3 Calcular precio de compra con 2 pedidos con stock
2.2 Ventas semanales
2.2.1 Calcular ventas semanales si no hay ventas
2.2.2 Calcular ventas semanales si hay ventas en las últimas 2 semanas.
2.3 Estado ventas
2.3.1 Calcular estado ventas si no hay ninguna vnta.
2.3.2 Calcular estado ventas si hay ventas la ultima semana pero no la anterior.
2.3.3 Calcular estado ventas si no hay ventas la ultima semana pero si la anterior.
2.3.4 Calcular estado ventas si hay ventas las 2 ultimas semanas
2.3.4.1 La evolución es positiva
2.3.4.2 La evolución es negativa
*/ 
